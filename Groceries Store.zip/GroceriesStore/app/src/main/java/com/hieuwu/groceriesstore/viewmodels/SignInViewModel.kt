package com.hieuwu.groceriesstore.viewmodels

import android.arch.lifecycle.ViewModel

class SignInViewModel : ViewModel() {
    private val _email: String? = "";
    private var _password: String? = "";
}