package com.hieuwu.groceriesstore.viewmodels

import android.arch.lifecycle.ViewModel

class SignUpViewModel: ViewModel() {


}